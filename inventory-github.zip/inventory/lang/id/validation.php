<?php

return [

    'required' => 'Kolom :attribute wajib diisi.',
    'email' => 'Format :attribute tidak valid.',
    'unique' => ':attribute sudah digunakan.',
    'confirmed' => 'Konfirmasi :attribute tidak cocok.',
    'string' => ':attribute harus berupa teks.',
    'integer' => ':attribute harus berupa bilangan bulat.',
    'numeric' => ':attribute harus berupa angka.',
    'date' => ':attribute bukan tanggal yang valid.',
    'in' => ':attribute yang dipilih tidak valid.',
    'exists' => ':attribute yang dipilih tidak valid.',

    'min' => [
        'numeric' => ':attribute minimal :min.',
        'string' => ':attribute minimal :min karakter.',
    ],

    'max' => [
        'numeric' => ':attribute maksimal :max.',
        'string' => ':attribute maksimal :max karakter.',
    ],

    'attributes' => [
        'name' => 'nama',
        'email' => 'email',
        'password' => 'password',
        'role' => 'role',
        'code' => 'kode',
        'description' => 'deskripsi',
        'contact_person' => 'nama kontak',
        'phone' => 'telepon',
        'address' => 'alamat',
        'category_id' => 'kategori',
        'location_id' => 'lokasi',
        'supplier_id' => 'pemasok',
        'sku' => 'SKU',
        'stock' => 'stok',
        'min_stock' => 'stok minimum',
        'price' => 'harga',
        'item_id' => 'barang',
        'quantity' => 'jumlah',
        'transaction_date' => 'tanggal transaksi',
        'source' => 'sumber',
        'destination' => 'tujuan',
        'notes' => 'catatan',
    ],

];
