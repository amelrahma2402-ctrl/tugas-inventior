<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'total_items' => \App\Models\Item::count(),
            'total_categories' => \App\Models\Category::count(),
            'total_locations' => \App\Models\Location::count(),
            'total_suppliers' => \App\Models\Supplier::count(),
            'total_stock_in' => \App\Models\StockIn::count(),
            'total_stock_out' => \App\Models\StockOut::count(),
        ];

        $lowStockItems = \App\Models\Item::lowStock()->with(['category', 'location'])->limit(5)->get();
        $recentTransactions = \App\Models\StockIn::with(['item', 'user'])->latest()->limit(5)->get()
            ->concat(\App\Models\StockOut::with(['item', 'user'])->latest()->limit(5)->get())
            ->sortByDesc('created_at')
            ->take(5);

        return view('dashboard', compact('stats', 'lowStockItems', 'recentTransactions'));
    }
}
