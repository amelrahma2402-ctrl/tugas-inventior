<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\StockIn;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StockInController extends Controller
{
    public function index(Request $request)
    {
        $query = StockIn::with(['item', 'user']);

        if ($request->filled('search')) {
            $query->whereHas('item', function ($q) use ($request) {
                $q->where('name', 'like', '%' . $request->search . '%')
                  ->orWhere('sku', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->filled('start_date')) {
            $query->whereDate('transaction_date', '>=', $request->start_date);
        }

        if ($request->filled('end_date')) {
            $query->whereDate('transaction_date', '<=', $request->end_date);
        }

        $totalQuantity = (clone $query)->sum('quantity');

        if ($request->filled('sort') && $request->sort === 'oldest') {
            $query->orderBy('transaction_date')->orderBy('id');
        } else {
            $query->orderByDesc('transaction_date')->orderByDesc('id');
        }

        $stockIns = $query->paginate(10)->withQueryString();

        return view('stock_ins.index', compact('stockIns', 'totalQuantity'));
    }

    public function create()
    {
        $items = Item::orderBy('name')->get();

        return view('stock_ins.create', compact('items'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'item_id' => 'required|exists:items,id',
            'quantity' => 'required|integer|min:1',
            'transaction_date' => 'required|date',
            'source' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ]);

        DB::transaction(function () use ($validated) {
            $item = Item::lockForUpdate()->findOrFail($validated['item_id']);
            $item->increment('stock', $validated['quantity']);

            StockIn::create([
                'item_id' => $item->id,
                'user_id' => auth()->id(),
                'quantity' => $validated['quantity'],
                'transaction_date' => $validated['transaction_date'],
                'source' => $validated['source'] ?? null,
                'notes' => $validated['notes'] ?? null,
            ]);
        });

        return redirect()->route('stock-ins.index')->with('success', 'Barang masuk berhasil dicatat.');
    }
}
