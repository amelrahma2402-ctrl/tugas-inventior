@extends('layouts.app')

@section('title', 'Dashboard')

@push('actions')
<span class="date-chip"><i class="bi bi-calendar3"></i> {{ now()->translatedFormat('d F Y') }}</span>
@endpush

@section('content')
<div class="mb-4">
    <h2 class="greeting">Selamat datang, {{ auth()->user()->name }}</h2>
    <p class="text-muted mb-0" style="font-size: 12.5px;">Ringkasan kondisi inventaris saat ini.</p>
</div>

<div class="row g-3 mb-4">
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-head">
                <span class="stat-label">Total Barang</span>
                <i class="bi bi-box stat-icon"></i>
            </div>
            <div class="stat-value">{{ number_format($stats['total_items']) }}</div>
            <div class="stat-foot">jenis barang tercatat</div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-head">
                <span class="stat-label">Kategori</span>
                <i class="bi bi-tags stat-icon"></i>
            </div>
            <div class="stat-value">{{ number_format($stats['total_categories']) }}</div>
            <div class="stat-foot">kelompok barang</div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-head">
                <span class="stat-label">Lokasi</span>
                <i class="bi bi-geo-alt stat-icon"></i>
            </div>
            <div class="stat-value">{{ number_format($stats['total_locations']) }}</div>
            <div class="stat-foot">titik penyimpanan</div>
        </div>
    </div>
    <div class="col-sm-6 col-xl-3">
        <div class="stat-card">
            <div class="stat-head">
                <span class="stat-label">Pemasok</span>
                <i class="bi bi-truck stat-icon"></i>
            </div>
            <div class="stat-value">{{ number_format($stats['total_suppliers']) }}</div>
            <div class="stat-foot">pemasok terdaftar</div>
        </div>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <div class="panel-title">
                    <span><i class="bi bi-exclamation-triangle" style="color: var(--gold);"></i> Stok Menipis</span>
                    <span class="badge badge-soft-warning">{{ $lowStockItems->count() }} item</span>
                </div>
            </div>
            <div class="card-body p-0">
                @if($lowStockItems->count() > 0)
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Barang</th>
                                <th>Lokasi</th>
                                <th>Stok</th>
                                <th>Minimum</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($lowStockItems as $item)
                            <tr>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->location->name ?? '-' }}</td>
                                <td><span class="badge badge-soft-danger">{{ $item->stock }}</span></td>
                                <td class="text-muted num">{{ $item->min_stock }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @else
                <div class="empty-state">
                    <i class="bi bi-check2-circle"></i>
                    <p>Semua stok dalam kondisi aman.</p>
                </div>
                @endif
            </div>
        </div>
    </div>

    <div class="col-lg-6">
        <div class="card h-100">
            <div class="card-header">
                <div class="panel-title">
                    <span><i class="bi bi-clock-history"></i> Transaksi Terakhir</span>
                </div>
            </div>
            <div class="card-body p-0">
                @if($recentTransactions->count() > 0)
                <div class="table-responsive">
                    <table class="table table-sm table-hover">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Barang</th>
                                <th>Tipe</th>
                                <th>Jumlah</th>
                                <th>Oleh</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recentTransactions as $transaction)
                            <tr>
                                <td class="text-muted num">{{ $transaction->transaction_date->format('d/m/Y') }}</td>
                                <td>{{ $transaction->item->name }}</td>
                                <td>
                                    @if($transaction instanceof \App\Models\StockIn)
                                    <span class="badge badge-soft-success">Masuk</span>
                                    @else
                                    <span class="badge badge-soft-danger">Keluar</span>
                                    @endif
                                </td>
                                <td class="num">{{ $transaction->quantity }}</td>
                                <td class="text-muted">{{ $transaction->user->name }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                @else
                <div class="empty-state">
                    <i class="bi bi-inbox"></i>
                    <p>Belum ada transaksi tercatat.</p>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection
