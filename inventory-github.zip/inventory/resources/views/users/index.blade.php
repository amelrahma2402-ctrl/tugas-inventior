@extends('layouts.app')

@section('title', 'Pengguna')

@push('actions')
<a href="{{ route('users.create') }}" class="btn btn-primary btn-sm">
    <i class="bi bi-plus-lg me-1"></i> Tambah Pengguna
</a>
@endpush

@section('content')
<div class="card table-card">
    <div class="card-body">
        <form action="{{ route('users.index') }}" method="GET">
            <div class="filter-row" style="grid-template-columns: minmax(200px, 2fr) minmax(130px, .8fr) minmax(150px, 1fr) auto;">
                <input type="text" name="search" class="form-control" placeholder="Cari nama atau email..." value="{{ request('search') }}">

                <select name="role" class="form-select">
                    <option value="">Semua Role</option>
                    <option value="admin" {{ request('role') == 'admin' ? 'selected' : '' }}>Admin</option>
                    <option value="staff" {{ request('role') == 'staff' ? 'selected' : '' }}>Staff</option>
                </select>

                <select name="sort" class="form-select">
                    <option value="name_asc" {{ request('sort', 'name_asc') == 'name_asc' ? 'selected' : '' }}>Nama A-Z</option>
                    <option value="name_desc" {{ request('sort') == 'name_desc' ? 'selected' : '' }}>Nama Z-A</option>
                    <option value="newest" {{ request('sort') == 'newest' ? 'selected' : '' }}>Terbaru</option>
                </select>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                    <a href="{{ route('users.index') }}" class="btn btn-outline-secondary">Reset</a>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th style="width: 50px;">No</th>
                        <th>Pengguna</th>
                        <th style="width: 100px;">Role</th>
                        <th style="width: 110px;">Trx Masuk</th>
                        <th style="width: 110px;">Trx Keluar</th>
                        <th style="width: 120px;">Dibuat</th>
                        <th style="width: 165px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($users as $user)
                    <tr>
                        <td class="text-muted num">{{ $loop->iteration + ($users->currentPage() - 1) * $users->perPage() }}</td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <span class="avatar" style="width: 30px; height: 30px; flex: 0 0 30px; background: var(--sunken); border-color: var(--line); color: var(--forest);">{{ strtoupper(substr($user->name, 0, 1)) }}</span>
                                <div>
                                    <div class="fw-medium">{{ $user->name }}</div>
                                    <div class="text-muted" style="font-size: 11.5px;">{{ $user->email }}</div>
                                </div>
                            </div>
                        </td>
                        <td>
                            @if($user->isAdmin())
                            <span class="badge badge-soft-warning">Admin</span>
                            @else
                            <span class="badge badge-soft-neutral">Staff</span>
                            @endif
                        </td>
                        <td class="num">{{ $user->stock_ins_count }}</td>
                        <td class="num">{{ $user->stock_outs_count }}</td>
                        <td class="text-muted num">{{ $user->created_at->format('d/m/Y') }}</td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="{{ route('users.edit', $user) }}" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                @if($user->id !== auth()->id())
                                <form action="{{ route('users.destroy', $user) }}" method="POST"
                                      onsubmit="return confirm('Hapus pengguna ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                                @endif
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p>Belum ada pengguna yang cocok.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
            <small class="text-muted">
                Menampilkan {{ $users->firstItem() ?? 0 }}–{{ $users->lastItem() ?? 0 }}
                dari {{ $users->total() }} pengguna
            </small>
            {{ $users->links() }}
        </div>
    </div>
</div>
@endsection
