<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Dashboard') &middot; {{ config('app.name') }}</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <style>
        :root {
            --sidebar-width: 244px;
            --paper: #f7f3ea;
            --surface: #fffdf8;
            --sunken: #efe8d8;
            --ink: #1e1b16;
            --muted: #6b6355;
            --line: #dcd2be;
            --line-soft: #eae2d0;
            --forest: #14352a;
            --forest-deep: #0c241c;
            --forest-soft: #3d6650;
            --gold: #a88a3f;
            --gold-soft: #ece1c4;
            --danger: #8c2a2a;
            --danger-soft: #f2e3df;
            --gain: #2e5d3d;
            --gain-soft: #e4ede2;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
            background: var(--paper);
            color: var(--ink);
            font-size: 14px;
            font-feature-settings: "tnum" 1;
        }

        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            width: var(--sidebar-width);
            background: var(--forest);
            display: flex;
            flex-direction: column;
            z-index: 1040;
            transform: translateX(-100%);
            transition: transform .2s ease;
        }

        .sidebar.show {
            transform: none;
        }

        .sidebar-brand {
            padding: 22px 20px 18px;
            border-bottom: 1px solid rgba(247, 243, 234, .12);
            color: #f7f3ea;
        }

        .sidebar-brand .wordmark {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 20px;
            font-weight: 600;
            line-height: 1.1;
            letter-spacing: -.01em;
        }

        .sidebar-brand .wordmark i {
            font-size: 17px;
            color: var(--gold);
            margin-right: 6px;
            vertical-align: 1px;
        }

        .sidebar-brand .tagline {
            margin-top: 5px;
            font-size: 9.5px;
            letter-spacing: .18em;
            text-transform: uppercase;
            color: rgba(247, 243, 234, .55);
        }

        .sidebar-nav {
            flex: 1;
            overflow-y: auto;
            padding: 14px 10px;
        }

        .sidebar-link {
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 9px 12px;
            margin-bottom: 2px;
            border-radius: 2px;
            color: rgba(247, 243, 234, .72);
            font-size: 13.5px;
            font-weight: 500;
            border-left: 2px solid transparent;
        }

        .sidebar-link i {
            font-size: 14px;
            width: 16px;
            text-align: center;
            color: rgba(247, 243, 234, .45);
        }

        .sidebar-link:hover {
            background: rgba(247, 243, 234, .06);
            color: #f7f3ea;
        }

        .sidebar-link.active {
            background: rgba(247, 243, 234, .08);
            border-left-color: var(--gold);
            color: #f7f3ea;
        }

        .sidebar-link.active i {
            color: var(--gold);
        }

        .sidebar-section {
            padding: 18px 12px 7px;
            font-size: 9.5px;
            font-weight: 600;
            letter-spacing: .16em;
            text-transform: uppercase;
            color: rgba(232, 217, 176, .8);
        }

        .sidebar-footer {
            margin-top: auto;
            border-top: 1px solid rgba(247, 243, 234, .12);
            padding: 14px 14px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .avatar {
            width: 32px;
            height: 32px;
            flex: 0 0 32px;
            border-radius: 50%;
            background: rgba(247, 243, 234, .12);
            color: #f7f3ea;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 15px;
            border: 1px solid rgba(247, 243, 234, .22);
        }

        .sidebar-footer .user-name {
            color: #f7f3ea;
            font-size: 12.5px;
            font-weight: 500;
            line-height: 1.2;
        }

        .sidebar-footer .user-role {
            color: rgba(247, 243, 234, .5);
            font-size: 10px;
            letter-spacing: .1em;
            text-transform: uppercase;
            line-height: 1.4;
        }

        .logout-btn {
            color: rgba(247, 243, 234, .5);
            border: 0;
            background: transparent;
            font-size: 15px;
            padding: 4px;
            line-height: 1;
        }

        .logout-btn:hover {
            color: #e8d9b0;
        }

        .sidebar-backdrop {
            position: fixed;
            inset: 0;
            background: rgba(20, 53, 42, .45);
            z-index: 1035;
            display: none;
        }

        .sidebar-backdrop.show {
            display: block;
        }

        /* Main */
        .main-wrapper {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .topbar {
            position: sticky;
            top: 0;
            z-index: 1020;
            background: var(--paper);
            border-bottom: 1px solid var(--line);
            padding: 13px 24px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
        }

        .topbar-eyebrow {
            font-size: 9.5px;
            letter-spacing: .18em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .topbar-title {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 22px;
            font-weight: 600;
            line-height: 1.2;
            margin: 0;
            letter-spacing: -.01em;
        }

        .content {
            padding: 26px 24px 40px;
            flex: 1;
        }

        /* Cards */
        .card {
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 4px;
            box-shadow: none;
        }

        .card-header {
            background: transparent;
            border-bottom: 1px solid var(--line);
            padding: 12px 18px;
            font-size: 10.5px;
            font-weight: 600;
            letter-spacing: .12em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .table-card .card-body {
            padding: 18px;
        }

        /* Buttons */
        .btn {
            border-radius: 3px;
            font-size: 12.5px;
            font-weight: 500;
            letter-spacing: .02em;
            padding: 7px 13px;
        }

        .btn-sm {
            font-size: 12px;
            padding: 5px 10px;
        }

        .btn-primary {
            --bs-btn-bg: var(--forest);
            --bs-btn-border-color: var(--forest);
            --bs-btn-color: #f7f3ea;
            --bs-btn-hover-bg: var(--forest-deep);
            --bs-btn-hover-border-color: var(--forest-deep);
            --bs-btn-hover-color: #f7f3ea;
            --bs-btn-active-bg: var(--forest-deep);
            --bs-btn-active-border-color: var(--forest-deep);
            --bs-btn-active-color: #f7f3ea;
        }

        .btn-outline-primary {
            --bs-btn-color: var(--forest);
            --bs-btn-border-color: var(--forest);
            --bs-btn-hover-bg: var(--forest);
            --bs-btn-hover-border-color: var(--forest);
            --bs-btn-hover-color: #f7f3ea;
        }

        .btn-outline-secondary {
            --bs-btn-color: #4f493e;
            --bs-btn-border-color: var(--line);
            --bs-btn-bg: var(--surface);
            --bs-btn-hover-bg: var(--sunken);
            --bs-btn-hover-color: var(--ink);
            --bs-btn-hover-border-color: var(--line);
        }

        .btn-outline-danger {
            --bs-btn-color: var(--danger);
            --bs-btn-border-color: #d9b6ad;
            --bs-btn-hover-bg: var(--danger);
            --bs-btn-hover-border-color: var(--danger);
            --bs-btn-hover-color: #fff;
        }

        /* Tables */
        .table {
            --bs-table-bg: transparent;
            font-size: 13.5px;
            margin-bottom: 0;
        }

        .table thead th {
            background: var(--sunken);
            color: #5e5648;
            font-size: 10px;
            font-weight: 600;
            letter-spacing: .1em;
            text-transform: uppercase;
            border-bottom: 1px solid var(--line);
            padding: 9px 12px;
            white-space: nowrap;
        }

        .table tbody td {
            padding: 11px 12px;
            border-bottom: 1px solid var(--line-soft);
            border-top: 0;
            vertical-align: middle;
        }

        .table-hover tbody tr:hover {
            --bs-table-hover-bg: #f6f0e2;
        }

        code {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 11.5px;
            color: var(--forest-soft);
            background: transparent;
        }

        .num {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 12.5px;
        }

        /* Badges */
        .badge {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-weight: 500;
            font-size: 10.5px;
            padding: 3px 7px;
            border-radius: 2px;
            letter-spacing: .02em;
        }

        .badge-soft-primary { background: #e9ede6; color: var(--forest); }
        .badge-soft-success { background: var(--gain-soft); color: var(--gain); }
        .badge-soft-warning { background: var(--gold-soft); color: #7a6429; }
        .badge-soft-danger  { background: var(--danger-soft); color: var(--danger); }
        .badge-soft-neutral { background: var(--sunken); color: #5e5648; }

        /* Alerts */
        .alert {
            border-radius: 3px;
            font-size: 13px;
            border: 1px solid transparent;
            padding: 11px 14px;
        }

        .alert-success {
            background: var(--gain-soft);
            border-color: #cfdcc9;
            color: #234b31;
        }

        .alert-danger {
            background: var(--danger-soft);
            border-color: #e3c8c0;
            color: #742323;
        }

        /* Forms */
        .form-label {
            font-size: 11px;
            font-weight: 600;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: #5e5648;
            margin-bottom: 6px;
        }

        .form-control,
        .form-select {
            font-size: 13px;
            color: var(--ink);
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 3px;
            padding: 8px 10px;
        }

        .form-control::placeholder {
            color: #a49a87;
        }

        .form-control:focus,
        .form-select:focus {
            border-color: var(--gold);
            box-shadow: 0 0 0 3px rgba(168, 138, 63, .15);
        }

        .form-text {
            font-size: 11.5px;
            color: var(--muted);
        }

        .required {
            color: var(--danger);
        }

        .form-check-input:checked {
            background-color: var(--forest);
            border-color: var(--forest);
        }

        /* Pagination */
        .pagination {
            --bs-pagination-font-size: 12px;
            --bs-pagination-color: #4f493e;
            --bs-pagination-bg: var(--surface);
            --bs-pagination-border-color: var(--line);
            --bs-pagination-hover-bg: var(--sunken);
            --bs-pagination-hover-color: var(--ink);
            --bs-pagination-hover-border-color: var(--line);
            --bs-pagination-active-bg: var(--forest);
            --bs-pagination-active-border-color: var(--forest);
            --bs-pagination-disabled-bg: var(--paper);
            margin-bottom: 0;
        }

        .page-link {
            padding: 5px 9px;
            border-radius: 2px;
        }

        /* Helpers */
        .text-muted {
            color: var(--muted) !important;
        }

        .filter-row {
            display: grid;
            grid-template-columns: minmax(180px, 2fr) minmax(150px, 1fr) minmax(150px, 1fr) minmax(150px, 1fr) auto;
            gap: 8px;
            margin-bottom: 16px;
        }

        @media (max-width: 767.98px) {
            .filter-row {
                grid-template-columns: 1fr;
            }
        }

        .empty-state {
            text-align: center;
            padding: 38px 20px;
            color: var(--muted);
        }

        .empty-state i {
            font-size: 24px;
            display: block;
            margin-bottom: 8px;
            color: #a49a87;
        }

        .empty-state p {
            margin: 0;
            font-size: 12.5px;
        }

        /* Dashboard */
        .greeting {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 23px;
            font-weight: 600;
            letter-spacing: -.01em;
            margin-bottom: 3px;
        }

        .stat-card {
            position: relative;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 4px;
            padding: 16px 20px;
            height: 100%;
        }

        .stat-card::before {
            content: "";
            position: absolute;
            left: 0;
            top: 16px;
            bottom: 16px;
            width: 3px;
            background: var(--gold);
        }

        .stat-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 8px;
        }

        .stat-label {
            font-size: 10px;
            font-weight: 600;
            letter-spacing: .12em;
            text-transform: uppercase;
            color: var(--muted);
        }

        .stat-icon {
            font-size: 15px;
            color: var(--forest-soft);
        }

        .stat-value {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 27px;
            font-weight: 500;
            letter-spacing: -.02em;
            line-height: 1.1;
        }

        .stat-foot {
            font-size: 11px;
            color: var(--muted);
            margin-top: 3px;
        }

        .date-chip {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 11px;
            color: var(--muted);
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 3px;
            padding: 5px 9px;
            white-space: nowrap;
            text-transform: uppercase;
            letter-spacing: .04em;
        }

        .panel-title {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 12px;
            width: 100%;
        }

        .panel-title span {
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }

        .table-sm thead th {
            padding: 8px 12px;
            font-size: 9.5px;
        }

        .table-sm tbody td {
            padding: 9px 12px;
        }

        @media (min-width: 992px) {
            .sidebar {
                transform: none;
            }

            .main-wrapper {
                margin-left: var(--sidebar-width);
            }

            .topbar,
            .content {
                padding-left: 30px;
                padding-right: 30px;
            }
        }
    </style>
</head>
<body>
    @auth
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-brand">
            <div class="wordmark"><i class="bi bi-box-seam"></i>Inventaris</div>
            <div class="tagline">Manajemen Stok Barang</div>
        </div>

        <nav class="sidebar-nav">
            <a href="{{ route('dashboard') }}" class="sidebar-link {{ request()->routeIs('dashboard') ? 'active' : '' }}">
                <i class="bi bi-grid-1x2"></i> Dashboard
            </a>
            <a href="{{ route('items.index') }}" class="sidebar-link {{ request()->routeIs('items.*') ? 'active' : '' }}">
                <i class="bi bi-box"></i> Barang
            </a>
            <a href="{{ route('categories.index') }}" class="sidebar-link {{ request()->routeIs('categories.*') ? 'active' : '' }}">
                <i class="bi bi-tags"></i> Kategori
            </a>
            <a href="{{ route('locations.index') }}" class="sidebar-link {{ request()->routeIs('locations.*') ? 'active' : '' }}">
                <i class="bi bi-geo-alt"></i> Lokasi
            </a>
            <a href="{{ route('suppliers.index') }}" class="sidebar-link {{ request()->routeIs('suppliers.*') ? 'active' : '' }}">
                <i class="bi bi-truck"></i> Pemasok
            </a>

            <div class="sidebar-section">Transaksi</div>
            <a href="{{ route('stock-ins.index') }}" class="sidebar-link {{ request()->routeIs('stock-ins.*') ? 'active' : '' }}">
                <i class="bi bi-box-arrow-in-down"></i> Barang Masuk
            </a>
            <a href="{{ route('stock-outs.index') }}" class="sidebar-link {{ request()->routeIs('stock-outs.*') ? 'active' : '' }}">
                <i class="bi bi-box-arrow-up"></i> Barang Keluar
            </a>

            @if(auth()->user()->isAdmin())
            <div class="sidebar-section">Administrasi</div>
            <a href="{{ route('users.index') }}" class="sidebar-link {{ request()->routeIs('users.*') ? 'active' : '' }}">
                <i class="bi bi-people"></i> Pengguna
            </a>
            @endif
        </nav>

        <div class="sidebar-footer">
            <span class="avatar">{{ strtoupper(substr(auth()->user()->name, 0, 1)) }}</span>
            <div class="flex-grow-1 overflow-hidden">
                <div class="user-name text-truncate">{{ auth()->user()->name }}</div>
                <div class="user-role">{{ ucfirst(auth()->user()->role) }}</div>
            </div>
            <form action="{{ route('logout') }}" method="POST">
                @csrf
                <button type="submit" class="logout-btn" title="Keluar">
                    <i class="bi bi-box-arrow-right"></i>
                </button>
            </form>
        </div>
    </aside>
    <div class="sidebar-backdrop" id="sidebarBackdrop"></div>

    <div class="main-wrapper">
        <header class="topbar">
            <div class="d-flex align-items-center gap-3">
                <button type="button" class="btn btn-outline-secondary btn-sm d-lg-none" id="sidebarToggle">
                    <i class="bi bi-list"></i>
                </button>
                <div>
                    <div class="topbar-eyebrow">Inventaris Barang</div>
                    <h1 class="topbar-title">@yield('title', 'Dashboard')</h1>
                </div>
            </div>
            <div class="d-flex align-items-center gap-2">
                @stack('actions')
            </div>
        </header>

        <main class="content">
            @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                {{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
            @endif

            @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                {{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>
            </div>
            @endif

            @yield('content')
        </main>
    </div>
    @else
    @yield('content')
    @endauth

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        const sidebar = document.getElementById('sidebar');
        const backdrop = document.getElementById('sidebarBackdrop');
        const toggle = document.getElementById('sidebarToggle');

        if (toggle && sidebar && backdrop) {
            toggle.addEventListener('click', function () {
                sidebar.classList.add('show');
                backdrop.classList.add('show');
            });

            backdrop.addEventListener('click', function () {
                sidebar.classList.remove('show');
                backdrop.classList.remove('show');
            });
        }
    </script>
    @stack('scripts')
</body>
</html>
