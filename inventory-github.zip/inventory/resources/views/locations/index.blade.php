@extends('layouts.app')

@section('title', 'Lokasi')

@push('actions')
<a href="{{ route('locations.create') }}" class="btn btn-primary btn-sm">
    <i class="bi bi-plus-lg me-1"></i> Tambah Lokasi
</a>
@endpush

@section('content')
<div class="card table-card">
    <div class="card-body">
        <form action="{{ route('locations.index') }}" method="GET">
            <div class="filter-row" style="grid-template-columns: minmax(200px, 2fr) auto;">
                <input type="text" name="search" class="form-control" placeholder="Cari nama atau kode lokasi..." value="{{ request('search') }}">
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                    <a href="{{ route('locations.index') }}" class="btn btn-outline-secondary">Reset</a>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th style="width: 50px;">No</th>
                        <th>Nama Lokasi</th>
                        <th>Kode</th>
                        <th>Deskripsi</th>
                        <th style="width: 110px;">Jumlah Barang</th>
                        <th style="width: 160px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($locations as $location)
                    <tr>
                        <td class="text-muted">{{ $loop->iteration + ($locations->currentPage() - 1) * $locations->perPage() }}</td>
                        <td class="fw-medium">{{ $location->name }}</td>
                        <td><code class="text-muted">{{ $location->code }}</code></td>
                        <td class="text-muted">{{ $location->description ?? '-' }}</td>
                        <td><span class="badge badge-soft-primary">{{ $location->items->count() }}</span></td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="{{ route('locations.edit', $location) }}" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <form action="{{ route('locations.destroy', $location) }}" method="POST"
                                      onsubmit="return confirm('Hapus lokasi ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p>Belum ada lokasi yang cocok.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
            <small class="text-muted">
                Menampilkan {{ $locations->firstItem() ?? 0 }}–{{ $locations->lastItem() ?? 0 }}
                dari {{ $locations->total() }} data
            </small>
            {{ $locations->links() }}
        </div>
    </div>
</div>
@endsection
