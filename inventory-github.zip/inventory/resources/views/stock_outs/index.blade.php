@extends('layouts.app')

@section('title', 'Barang Keluar')

@push('actions')
<a href="{{ route('stock-outs.create') }}" class="btn btn-primary btn-sm">
    <i class="bi bi-plus-lg me-1"></i> Catat Barang Keluar
</a>
@endpush

@section('content')
<div class="card table-card">
    <div class="card-body">
        <form action="{{ route('stock-outs.index') }}" method="GET">
            <div class="filter-row">
                <input type="text" name="search" class="form-control" placeholder="Cari nama atau SKU barang..." value="{{ request('search') }}">

                <input type="date" name="start_date" class="form-control" value="{{ request('start_date') }}" title="Dari tanggal">

                <input type="date" name="end_date" class="form-control" value="{{ request('end_date') }}" title="Sampai tanggal">

                <select name="sort" class="form-select">
                    <option value="newest" {{ request('sort', 'newest') == 'newest' ? 'selected' : '' }}>Terbaru</option>
                    <option value="oldest" {{ request('sort') == 'oldest' ? 'selected' : '' }}>Terlama</option>
                </select>

                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                    <a href="{{ route('stock-outs.index') }}" class="btn btn-outline-secondary">Reset</a>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th style="width: 110px;">Tanggal</th>
                        <th>Barang</th>
                        <th style="width: 100px;">Jumlah</th>
                        <th>Tujuan</th>
                        <th>Catatan</th>
                        <th style="width: 140px;">Dicatat Oleh</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($stockOuts as $stockOut)
                    <tr>
                        <td class="text-muted num">{{ $stockOut->transaction_date->format('d/m/Y') }}</td>
                        <td>
                            <div class="fw-medium">{{ $stockOut->item->name }}</div>
                            <code>{{ $stockOut->item->sku }}</code>
                        </td>
                        <td><span class="badge badge-soft-danger">-{{ $stockOut->quantity }}</span></td>
                        <td>{{ $stockOut->destination ?? '-' }}</td>
                        <td class="text-muted">{{ $stockOut->notes ?? '-' }}</td>
                        <td class="text-muted">{{ $stockOut->user->name }}</td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="6">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p>Belum ada transaksi barang keluar.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
            <small class="text-muted">
                Menampilkan {{ $stockOuts->firstItem() ?? 0 }}–{{ $stockOuts->lastItem() ?? 0 }}
                dari {{ $stockOuts->total() }} transaksi
                &middot; Total kuantitas: <span class="num">{{ number_format($totalQuantity, 0, ',', '.') }}</span> unit
            </small>
            {{ $stockOuts->links() }}
        </div>
    </div>
</div>
@endsection
