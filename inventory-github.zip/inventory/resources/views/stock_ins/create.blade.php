@extends('layouts.app')

@section('title', 'Catat Barang Masuk')

@push('actions')
<a href="{{ route('stock-ins.index') }}" class="btn btn-outline-secondary btn-sm">
    <i class="bi bi-arrow-left me-1"></i> Kembali
</a>
@endpush

@section('content')
<div class="row">
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">Detail Barang Masuk</div>
            <div class="card-body p-4">
                <form action="{{ route('stock-ins.store') }}" method="POST">
                    @csrf

                    <div class="mb-3">
                        <label for="item_id" class="form-label">Barang <span class="required">*</span></label>
                        <select class="form-select @error('item_id') is-invalid @enderror" id="item_id" name="item_id" required>
                            <option value="">Pilih barang</option>
                            @foreach($items as $item)
                            <option value="{{ $item->id }}" data-stock="{{ $item->stock }}"
                                    {{ old('item_id') == $item->id ? 'selected' : '' }}>
                                {{ $item->sku }} — {{ $item->name }} (stok: {{ $item->stock }})
                            </option>
                            @endforeach
                        </select>
                        <div class="form-text" id="stockHint"></div>
                        @error('item_id')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="quantity" class="form-label">Jumlah Masuk <span class="required">*</span></label>
                            <input type="number" class="form-control @error('quantity') is-invalid @enderror"
                                   id="quantity" name="quantity" value="{{ old('quantity') }}" min="1" required>
                            @error('quantity')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="transaction_date" class="form-label">Tanggal <span class="required">*</span></label>
                            <input type="date" class="form-control @error('transaction_date') is-invalid @enderror"
                                   id="transaction_date" name="transaction_date"
                                   value="{{ old('transaction_date', now()->toDateString()) }}" required>
                            @error('transaction_date')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="source" class="form-label">Sumber</label>
                            <input type="text" class="form-control @error('source') is-invalid @enderror"
                                   id="source" name="source" value="{{ old('source') }}"
                                   placeholder="Contoh: Pembelian supplier">
                            @error('source')
                            <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="notes" class="form-label">Catatan</label>
                        <textarea class="form-control @error('notes') is-invalid @enderror"
                                  id="notes" name="notes" rows="3">{{ old('notes') }}</textarea>
                        @error('notes')
                        <div class="invalid-feedback">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="d-flex gap-2">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-lg me-1"></i> Simpan
                        </button>
                        <a href="{{ route('stock-ins.index') }}" class="btn btn-outline-secondary">Batal</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
    const itemSelect = document.getElementById('item_id');
    const stockHint = document.getElementById('stockHint');

    function updateStockHint() {
        const option = itemSelect.options[itemSelect.selectedIndex];

        if (option && option.dataset.stock !== undefined) {
            stockHint.textContent = 'Stok saat ini: ' + option.dataset.stock + ' unit.';
        } else {
            stockHint.textContent = '';
        }
    }

    if (itemSelect) {
        itemSelect.addEventListener('change', updateStockHint);
        updateStockHint();
    }
</script>
@endpush
