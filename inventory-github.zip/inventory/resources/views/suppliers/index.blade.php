@extends('layouts.app')

@section('title', 'Pemasok')

@push('actions')
<a href="{{ route('suppliers.create') }}" class="btn btn-primary btn-sm">
    <i class="bi bi-plus-lg me-1"></i> Tambah Pemasok
</a>
@endpush

@section('content')
<div class="card table-card">
    <div class="card-body">
        <form action="{{ route('suppliers.index') }}" method="GET">
            <div class="filter-row" style="grid-template-columns: minmax(200px, 2fr) auto;">
                <input type="text" name="search" class="form-control" placeholder="Cari nama pemasok atau kontak..." value="{{ request('search') }}">
                <div class="d-flex gap-2">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search me-1"></i> Cari
                    </button>
                    <a href="{{ route('suppliers.index') }}" class="btn btn-outline-secondary">Reset</a>
                </div>
            </div>
        </form>

        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th style="width: 50px;">No</th>
                        <th>Nama Pemasok</th>
                        <th>Kontak</th>
                        <th>Telepon</th>
                        <th>Email</th>
                        <th style="width: 110px;">Jumlah Barang</th>
                        <th style="width: 160px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($suppliers as $supplier)
                    <tr>
                        <td class="text-muted">{{ $loop->iteration + ($suppliers->currentPage() - 1) * $suppliers->perPage() }}</td>
                        <td class="fw-medium">{{ $supplier->name }}</td>
                        <td class="text-muted">{{ $supplier->contact_person ?? '-' }}</td>
                        <td>{{ $supplier->phone ?? '-' }}</td>
                        <td class="text-muted">{{ $supplier->email ?? '-' }}</td>
                        <td><span class="badge badge-soft-primary">{{ $supplier->items->count() }}</span></td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="{{ route('suppliers.edit', $supplier) }}" class="btn btn-sm btn-outline-secondary">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <form action="{{ route('suppliers.destroy', $supplier) }}" method="POST"
                                      onsubmit="return confirm('Hapus pemasok ini?')">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="7">
                            <div class="empty-state">
                                <i class="bi bi-inbox"></i>
                                <p>Belum ada pemasok yang cocok.</p>
                            </div>
                        </td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mt-3">
            <small class="text-muted">
                Menampilkan {{ $suppliers->firstItem() ?? 0 }}–{{ $suppliers->lastItem() ?? 0 }}
                dari {{ $suppliers->total() }} data
            </small>
            {{ $suppliers->links() }}
        </div>
    </div>
</div>
@endsection
