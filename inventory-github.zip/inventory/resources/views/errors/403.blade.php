@extends('layouts.app')

@section('title', 'Akses Ditolak')

@section('content')
<div class="row justify-content-center">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-body p-5 text-center">
                <div style="width: 56px; height: 56px; border-radius: 50%; background: var(--danger-soft); color: var(--danger); display: inline-flex; align-items: center; justify-content: center; font-size: 24px; margin-bottom: 18px;">
                    <i class="bi bi-lock"></i>
                </div>

                <h2 class="greeting mb-2">Akses ditolak</h2>
                <p class="text-muted mb-4" style="font-size: 13px;">
                    Halaman ini hanya dapat diakses oleh pengguna dengan role admin.
                    Akun Anda tidak memiliki izin untuk membuka halaman tersebut.
                </p>

                <a href="{{ route('dashboard') }}" class="btn btn-primary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali ke Dashboard
                </a>
            </div>
        </div>
    </div>
</div>
@endsection
