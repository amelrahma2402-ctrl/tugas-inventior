<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Masuk &middot; {{ config('app.name') }}</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">

    <style>
        :root {
            --paper: #f7f3ea;
            --surface: #fffdf8;
            --sunken: #efe8d8;
            --ink: #1e1b16;
            --muted: #6b6355;
            --line: #dcd2be;
            --forest: #14352a;
            --forest-deep: #0c241c;
            --gold: #a88a3f;
            --danger: #8c2a2a;
        }

        body {
            font-family: 'Inter', system-ui, -apple-system, 'Segoe UI', sans-serif;
            background: var(--paper);
            color: var(--ink);
            font-size: 14px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
            font-feature-settings: "tnum" 1;
        }

        .login-shell {
            width: 100%;
            max-width: 900px;
            background: var(--surface);
            border: 1px solid var(--line);
            border-radius: 4px;
            overflow: hidden;
            display: grid;
            grid-template-columns: 0.92fr 1.08fr;
        }

        .login-panel {
            background: var(--forest);
            color: #f7f3ea;
            padding: 40px 36px;
            display: flex;
            flex-direction: column;
        }

        .login-brand {
            display: flex;
            align-items: baseline;
            gap: 8px;
            margin-bottom: 52px;
        }

        .login-brand .wordmark {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 20px;
            font-weight: 600;
            line-height: 1;
            letter-spacing: -.01em;
        }

        .login-brand .wordmark i {
            font-size: 17px;
            color: var(--gold);
            margin-right: 5px;
            vertical-align: 1px;
        }

        .login-brand .tagline {
            font-size: 9px;
            letter-spacing: .17em;
            text-transform: uppercase;
            color: rgba(247, 243, 234, .5);
        }

        .login-panel .rule {
            width: 44px;
            height: 2px;
            background: var(--gold);
            margin-bottom: 20px;
        }

        .login-panel h2 {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 29px;
            font-weight: 600;
            line-height: 1.2;
            letter-spacing: -.015em;
            margin-bottom: 16px;
        }

        .login-panel p {
            color: rgba(247, 243, 234, .62);
            font-size: 12.5px;
            line-height: 1.65;
            margin-bottom: 30px;
            max-width: 300px;
        }

        .feature-list {
            list-style: none;
            padding: 0;
            margin: 0 0 32px;
        }

        .feature-list li {
            display: flex;
            align-items: flex-start;
            gap: 9px;
            color: rgba(247, 243, 234, .78);
            font-size: 12px;
            margin-bottom: 10px;
        }

        .feature-list i {
            color: var(--gold);
            font-size: 13px;
            margin-top: 1px;
        }

        .login-panel-footer {
            margin-top: auto;
            padding-top: 24px;
            border-top: 1px solid rgba(247, 243, 234, .12);
            color: rgba(247, 243, 234, .4);
            font-size: 9.5px;
            letter-spacing: .14em;
            text-transform: uppercase;
        }

        .login-form {
            padding: 40px 40px 34px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        .mobile-brand {
            display: none;
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 20px;
            font-weight: 600;
            letter-spacing: -.01em;
            margin-bottom: 22px;
        }

        .mobile-brand i {
            color: var(--gold);
            font-size: 17px;
            margin-right: 5px;
        }

        .login-form h1 {
            font-family: 'Space Grotesk', 'Inter', sans-serif;
            font-size: 24px;
            font-weight: 600;
            letter-spacing: -.01em;
            margin-bottom: 5px;
        }

        .login-form .subtitle {
            color: var(--muted);
            font-size: 12.5px;
            margin-bottom: 28px;
        }

        .form-label {
            font-size: 11px;
            font-weight: 600;
            letter-spacing: .1em;
            text-transform: uppercase;
            color: #5e5648;
            margin-bottom: 4px;
        }

        .form-control {
            font-size: 13.5px;
            color: var(--ink);
            background: transparent;
            border: 0;
            border-bottom: 1px solid var(--line);
            border-radius: 0;
            padding: 8px 0 9px;
        }

        .form-control:focus {
            background: transparent;
            border-bottom-color: var(--gold);
            box-shadow: none;
        }

        .form-control.is-invalid {
            border-bottom-color: var(--danger);
            background: transparent;
        }

        .invalid-feedback {
            font-size: 11.5px;
        }

        .form-check-label {
            font-size: 12.5px;
            color: var(--muted);
        }

        .form-check-input {
            border-color: var(--line);
            border-radius: 2px;
        }

        .form-check-input:checked {
            background-color: var(--forest);
            border-color: var(--forest);
        }

        .btn-primary {
            --bs-btn-bg: var(--forest);
            --bs-btn-border-color: var(--forest);
            --bs-btn-color: #f7f3ea;
            --bs-btn-hover-bg: var(--forest-deep);
            --bs-btn-hover-border-color: var(--forest-deep);
            --bs-btn-hover-color: #f7f3ea;
            --bs-btn-active-bg: var(--forest-deep);
            --bs-btn-active-border-color: var(--forest-deep);
            border-radius: 3px;
            font-size: 13px;
            font-weight: 500;
            letter-spacing: .03em;
            padding: 10px 14px;
        }

        .alert {
            border-radius: 3px;
            font-size: 12.5px;
            border: 1px solid #e3c8c0;
            background: #f2e3df;
            color: #742323;
            padding: 10px 12px;
        }

        .alert ul {
            padding-left: 18px;
        }

        .demo-box {
            margin-top: 28px;
            border-top: 1px solid var(--line);
            padding-top: 14px;
        }

        .demo-box .demo-title {
            font-size: 9.5px;
            font-weight: 600;
            letter-spacing: .13em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 7px;
        }

        .demo-box .demo-row {
            display: flex;
            justify-content: space-between;
            gap: 12px;
            font-size: 11.5px;
            color: var(--muted);
            padding: 2px 0;
        }

        .demo-box code {
            font-family: 'JetBrains Mono', Consolas, monospace;
            font-size: 10.5px;
            color: var(--forest);
        }

        @media (max-width: 767.98px) {
            body {
                padding: 16px;
            }

            .login-shell {
                grid-template-columns: 1fr;
                max-width: 420px;
            }

            .login-panel {
                display: none;
            }

            .login-form {
                padding: 30px 24px 28px;
            }

            .mobile-brand {
                display: block;
            }
        }
    </style>
</head>
<body>
    <div class="login-shell">
        <div class="login-panel">
            <div class="login-brand">
                <span class="wordmark"><i class="bi bi-box-seam"></i>Inventaris</span>
                <span class="tagline">Manajemen Stok</span>
            </div>

            <div class="rule"></div>
            <h2>Setiap barang tercatat, setiap stok terjaga.</h2>
            <p>Pencatatan barang masuk dan keluar, pemantauan stok minimum, serta data master dalam satu sistem.</p>

            <ul class="feature-list">
                <li><i class="bi bi-dash"></i> Data barang, kategori, lokasi, dan pemasok terpusat</li>
                <li><i class="bi bi-dash"></i> Riwayat transaksi tercatat per pengguna</li>
                <li><i class="bi bi-dash"></i> Hak akses terpisah untuk admin dan staff</li>
            </ul>

            <div class="login-panel-footer">
                Sistem Informasi Manajemen Inventaris Barang
            </div>
        </div>

        <div class="login-form">
            <div class="mobile-brand"><i class="bi bi-box-seam"></i>Inventaris</div>

            <h1>Masuk ke akun</h1>
            <p class="subtitle">Gunakan email dan password yang sudah terdaftar.</p>

            @if($errors->any())
            <div class="alert mb-4">
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                    <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
            @endif

            <form action="{{ route('login') }}" method="POST">
                @csrf

                <div class="mb-4">
                    <label for="email" class="form-label">Email</label>
                    <input type="email" class="form-control @error('email') is-invalid @enderror"
                           id="email" name="email" value="{{ old('email') }}" required autofocus>
                    @error('email')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control @error('password') is-invalid @enderror"
                           id="password" name="password" required>
                    @error('password')
                    <div class="invalid-feedback">{{ $message }}</div>
                    @enderror
                </div>

                <div class="d-flex align-items-center justify-content-between mb-4">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="remember" name="remember">
                        <label class="form-check-label" for="remember">Ingat saya</label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100">Masuk</button>
            </form>

            <div class="demo-box">
                <div class="demo-title">Akun demo</div>
                <div class="demo-row">
                    <span>Admin</span>
                    <code>admin@example.com / password</code>
                </div>
                <div class="demo-row">
                    <span>Staff</span>
                    <code>staff@example.com / password</code>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
