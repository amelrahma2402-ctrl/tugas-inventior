<?php

namespace Database\Seeders;

use App\Models\Category;
use App\Models\Location;
use App\Models\Supplier;
use App\Models\Item;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class InventorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['name' => 'Elektronik', 'description' => 'Peralatan elektronik'],
            ['name' => 'Kantor', 'description' => 'Perlengkapan kantor'],
            ['name' => 'Bahan Baku', 'description' => 'Bahan produksi'],
        ];

        foreach ($categories as $cat) {
            Category::create([
                'name' => $cat['name'],
                'slug' => Str::slug($cat['name']),
                'description' => $cat['description'],
            ]);
        }

        $locations = [
            ['name' => 'Gudang A', 'code' => 'GA-001'],
            ['name' => 'Gudang B', 'code' => 'GB-001'],
            ['name' => 'Rak Display', 'code' => 'RD-001'],
        ];

        foreach ($locations as $loc) {
            Location::create([
                'name' => $loc['name'],
                'code' => $loc['code'],
            ]);
        }

        $suppliers = [
            ['name' => 'PT. Maju Jaya', 'contact_person' => 'Budi', 'phone' => '081234567890'],
            ['name' => 'CV. Sentosa', 'contact_person' => 'Siti', 'phone' => '081234567891'],
        ];

        foreach ($suppliers as $sup) {
            Supplier::create($sup);
        }

        $items = [
            ['name' => 'Laptop', 'sku' => 'ELEC-001', 'category' => 1, 'location' => 1, 'supplier' => 1, 'stock' => 10, 'min_stock' => 5, 'price' => 5000000],
            ['name' => 'Mouse Wireless', 'sku' => 'ELEC-002', 'category' => 1, 'location' => 1, 'supplier' => 1, 'stock' => 50, 'min_stock' => 10, 'price' => 150000],
            ['name' => 'Kertas A4', 'sku' => 'KANT-001', 'category' => 2, 'location' => 2, 'supplier' => 2, 'stock' => 100, 'min_stock' => 20, 'price' => 45000],
            ['name' => 'Pena Hitam', 'sku' => 'KANT-002', 'category' => 2, 'location' => 2, 'supplier' => 2, 'stock' => 200, 'min_stock' => 50, 'price' => 5000],
        ];

        foreach ($items as $item) {
            Item::create([
                'name' => $item['name'],
                'sku' => $item['sku'],
                'category_id' => $item['category'],
                'location_id' => $item['location'],
                'supplier_id' => $item['supplier'],
                'stock' => $item['stock'],
                'min_stock' => $item['min_stock'],
                'price' => $item['price'],
            ]);
        }
    }
}
